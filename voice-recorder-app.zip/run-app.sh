#!/bin/bash

echo "Starting Voice Recorder App..."
echo
echo "Please wait while we start a local web server for the app."
echo

# Check if Python 3 is available
if command -v python3 &>/dev/null; then
    echo "Using Python 3..."
    # Open the browser (works on macOS, most Linux distros)
    if [[ "$OSTYPE" == "darwin"* ]]; then
        open http://localhost:8000
    elif command -v xdg-open &>/dev/null; then
        xdg-open http://localhost:8000
    elif command -v gnome-open &>/dev/null; then
        gnome-open http://localhost:8000
    fi
    # Start the server
    python3 -m http.server 8000
    exit 0
fi

# Check if Python is available and is Python 3
if command -v python &>/dev/null; then
    version=$(python --version 2>&1)
    if [[ $version == *"Python 3"* ]]; then
        echo "Using Python 3..."
        # Open the browser
        if [[ "$OSTYPE" == "darwin"* ]]; then
            open http://localhost:8000
        elif command -v xdg-open &>/dev/null; then
            xdg-open http://localhost:8000
        elif command -v gnome-open &>/dev/null; then
            gnome-open http://localhost:8000
        fi
        # Start the server
        python -m http.server 8000
        exit 0
    else
        echo "Using Python 2..."
        # Open the browser
        if [[ "$OSTYPE" == "darwin"* ]]; then
            open http://localhost:8000
        elif command -v xdg-open &>/dev/null; then
            xdg-open http://localhost:8000
        elif command -v gnome-open &>/dev/null; then
            gnome-open http://localhost:8000
        fi
        # Start the server
        python -m SimpleHTTPServer 8000
        exit 0
    fi
fi

echo "Python not found! Please install Python or open 'index.html' directly."
echo "Press Enter to open index.html in your default browser (if possible)..."
read

# Try to open the index.html file
if [[ "$OSTYPE" == "darwin"* ]]; then
    open index.html
elif command -v xdg-open &>/dev/null; then
    xdg-open index.html
elif command -v gnome-open &>/dev/null; then
    gnome-open index.html
else
    echo "Could not open browser automatically. Please open 'index.html' manually."
fi 